
document.addEventListener("DOMContentLoaded", function () {
    document.querySelector(".button-defaults").addEventListener("click", setDefaultValues);
    document.querySelector(".button-clear").addEventListener("click", clearInputValues);
    document.querySelector(".button-rich").addEventListener("click", calculateRetirement);
  });
  
  // Function to set default values
  function setDefaultValues() {
    document.getElementById("startingAge").value = "25";
    document.getElementById("retirementAge").value = "65";
    document.getElementById("startingSalary").value = "50000";
    document.getElementById("annualSavingsPercent").value = "10";
    document.getElementById("annualRaisePercent").value = "1";
    document.getElementById("interestRate").value = "5";
  }
  
  // Function to clear input values
  function clearInputValues() {
    document.getElementById("startingAge").value = "";
    document.getElementById("retirementAge").value = "";
    document.getElementById("startingSalary").value = "";
    document.getElementById("annualSavingsPercent").value = "";
    document.getElementById("annualRaisePercent").value = "";
    document.getElementById("interestRate").value = "";
  }
  
  // Define retirement calculations
  function calculateRetirement() {
    // Retrieve input values
    var startingAge = parseInt(document.getElementById("startingAge").value);
    var retirementAge = parseInt(document.getElementById("retirementAge").value);
    var startingSalary = parseFloat(document.getElementById("startingSalary").value);
    var annualSavingsPercent = parseFloat(document.getElementById("annualSavingsPercent").value) / 100;
    var annualRaisePercent = parseFloat(document.getElementById("annualRaisePercent").value) / 100;
    var interestRate = parseFloat(document.getElementById("interestRate").value) / 100;
   

    // Calculate retirement
    var yearsToInvest = retirementAge - startingAge;
    var currentAge = startingAge;
    var currentSalary = startingSalary;
    var currentRetirement = 0;
    var lifetimeSalary = 0;
    var totalSaved = 0;
    var earnedInterest = 0;
  
    // Initialize table elements
    var detailTableBody = document.getElementById("second-additional-table").getElementsByTagName("tbody")[0];
    var summaryTableRows = document.getElementById("additional-table").getElementsByTagName("tr");
   
    console.log("Age  Salary  Savings  Interest  Retirement");
  
    for (let year = 0; year <= yearsToInvest; year++) {
      var currentSavings = currentSalary * annualSavingsPercent;
      var currentInterest = (currentRetirement + currentSavings) * interestRate;
      currentRetirement += currentSavings + currentInterest;
  
      // Log values to console
      console.log(currentAge, currentSalary, currentSavings, currentInterest, currentRetirement);
  
      // Add row to detail table
      var row = detailTableBody.insertRow();
      row.insertCell(0).textContent = currentAge;
      row.insertCell(1).textContent = currentSalary.toFixed(2);
      row.insertCell(2).textContent = currentSavings.toFixed(2);
      row.insertCell(3).textContent = currentInterest.toFixed(2);
      row.insertCell(4).textContent = currentRetirement.toFixed(2);
  
      // Update totals
      lifetimeSalary += currentSalary;
      totalSaved += currentSavings;
      earnedInterest += currentInterest;
  
      currentAge++;
      currentSalary += currentSalary * annualRaisePercent;
    }
    console.log("Years to invest:", yearsToInvest);
    console.log("Retirement Fund:", currentRetirement);
    console.log("Lifetime Salary:", lifetimeSalary);
    console.log("Total Saved:", totalSaved);
    console.log("Earned Interest:", earnedInterest);

    
document.getElementById("yearsInvested").textContent = yearsToInvest;
document.getElementById("currentRetirement").textContent = currentRetirement.toFixed(2);
document.getElementById("lifetimeSalary").textContent = lifetimeSalary.toFixed(2);
document.getElementById("totalSaved").textContent = totalSaved.toFixed(2);
document.getElementById("earnedInterest").textContent = earnedInterest.toFixed(2);

  
    }
    
  
  
  